package com.yash.reservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
